// Original repeating instrumental loop, rendered locally with Web Audio.
const townMusic = (() => {
  const control = document.querySelector('#music-toggle');
  let enabled = true;
  let started = false;
  let context;
  let master;
  let timer;
  let nextBeat = 0;
  let beat = 0;
  let failed = false;
  // Each new visit starts with music enabled.

  const secondsPerBeat = 60 / 76;
  const chords = [
    [48, 55, 60, 64], [45, 52, 57, 60], [41, 48, 57, 60], [43, 50, 55, 62],
    [48, 55, 59, 64], [45, 52, 60, 64], [41, 48, 57, 60], [43, 50, 59, 62],
  ];
  const melody = [
    [72, 0, 76, 74, 0, 72, 67, 0], [69, 0, 72, 0, 76, 72, 0, 0],
    [69, 0, 72, 74, 0, 72, 69, 0], [67, 0, 71, 74, 0, 71, 67, 0],
    [76, 0, 79, 76, 0, 74, 72, 0], [72, 0, 76, 0, 74, 72, 69, 0],
    [69, 0, 72, 0, 74, 72, 69, 0], [71, 0, 74, 71, 0, 67, 0, 0],
  ];

  function updateControl() {
    control.textContent = failed ? '音樂・點擊重試' : enabled ? '音樂：開' : '音樂：關';
    control.setAttribute('aria-pressed', String(enabled && !failed));
    control.setAttribute('aria-label', enabled && !failed ? '關閉背景音樂' : '開啟背景音樂');
  }

  function note(midi, at, duration, volume) {
    const envelope = context.createGain();
    envelope.gain.setValueAtTime(0, at);
    envelope.gain.linearRampToValueAtTime(volume, at + .035);
    envelope.gain.exponentialRampToValueAtTime(.0001, at + duration);
    envelope.connect(master);
    // A soft fundamental with a quiet octave gives a rounded, plucked timbre.
    let remaining = 2;
    for (const [octave, level] of [[0, 1], [12, .12]]) {
      const oscillator = context.createOscillator();
      const partial = context.createGain();
      oscillator.type = 'sine';
      oscillator.frequency.value = 440 * 2 ** ((midi + octave - 69) / 12);
      partial.gain.value = level;
      oscillator.connect(partial);
      partial.connect(envelope);
      oscillator.start(at);
      oscillator.stop(at + duration + .02);
      oscillator.onended = () => {
        oscillator.disconnect();
        partial.disconnect();
        remaining--;
        if (remaining === 0) envelope.disconnect();
      };
    }

  }

  function schedule() {
    if (!enabled || document.hidden || context.state !== 'running') return;
    while (nextBeat < context.currentTime + .18) {
      const phrase = Math.floor(beat / 8) % 8;
      const position = beat % 8;
      const chord = chords[phrase];
      note(chord[[0, 2, 1, 3][position % 4]], nextBeat, 2.4, .13);
      const pitch = melody[phrase][position];
      if (pitch) note(pitch, nextBeat + .025, 2.7, .14);
      nextBeat += secondsPerBeat;
      beat = (beat + 1) % 256;
    }
  }

  async function sync() {
    clearInterval(timer);
    if (!enabled || !started || document.hidden) {
      if (context?.state === 'running') await context.suspend();
      return;
    }
    try {
      if (!context) {
        const Audio = window.AudioContext || window.webkitAudioContext;
        if (!Audio) throw new Error('Audio unavailable');
        context = new Audio();
        master = context.createGain();
        master.gain.value = .24;
        master.connect(context.destination);
        nextBeat = context.currentTime + .08;
      }
      await context.resume();
      if (!enabled || document.hidden) { await context.suspend(); return; }
      failed = false;
      nextBeat = Math.max(nextBeat, context.currentTime + .04);
      clearInterval(timer);
      schedule();
      timer = setInterval(schedule, 80);
    } catch {
      failed = true;
    }
    updateControl();
  }

  control.addEventListener('click', () => {
    enabled = failed || !enabled;
    started = true;
    failed = false;
    updateControl();
    void sync();
  });
  document.addEventListener('visibilitychange', () => { void sync(); });
  window.addEventListener('pagehide', () => { clearInterval(timer); void context?.suspend(); });
  window.addEventListener('pageshow', () => { if (started) void sync(); });
  updateControl();
  return {
    start() {
      started = true;
      updateControl();
      void sync();
    },
  };
})();
