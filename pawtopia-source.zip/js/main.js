const scene = document.querySelector('#scene');
const strengths = strengthGroups.flatMap(group => group.strengths.map(([id, name, description, example]) => ({ id, name, description, example, group: group.name })));
let strengthIndex = 0;
let companion;
let strength;
let career;
let feedingTimer;
let movementTimer;
let movementFrame;
const favorites = new Set();
try {
  const saved = JSON.parse(localStorage.getItem('pawtopia.favorites') || '[]');
  if (Array.isArray(saved)) saved.filter(id => strengths.some(item => item.id === id)).slice(0, 3).forEach(id => favorites.add(id));
} catch {}
const explored = new Set();
const trainingStops = [
  { name: '課務電腦', x: 20, y: 42, type: '日常工作',
    lines: ['下週有一梯門市新人訓練。暖暖在行事曆上核對講師、教室與學員班表，再寄出課程通知。', '開課前，牠確認投影設備、準備教材和簽到名單。學員到場後，牠協助報到，讓講師能準時開始。'],
    result: '課程時間與資源確認完成，學員收到通知。' },
  { name: '訓練資料夾', x: 50, y: 48, type: '日常工作',
    lines: ['暖暖打開上一梯的出席紀錄、練習結果和回饋。有人完成簽到，但實作練習還有卡關的地方。', '牠將出席與學習結果分別整理，把需要協助的項目交給講師與門市帶教同仁討論，並更新訓練紀錄。'],
    result: '整理出需要補充練習的項目，交給講師與帶教同仁。' },
  { name: '辦公室電話', x: 84, y: 48, type: '常見挑戰',
    lines: ['辦公室電話響起，暖暖接到門市來電：「新人上過報修課，回到現場卻找不到設備編號。」暖暖打開教室範例和門市照片，發現兩種設備的貼紙位置不同。', '暖暖先向帶教同仁了解實際困難，再請講師補上門市照片和練習。牠約好下一次追蹤，確認新人能否在現場完成操作。'],
    result: '教材補上現場案例，並安排後續追蹤。' },
];
const workplaceAtlases = [
  ['training', 'service', 'social-work', 'graphic', 'logistics', 'events'],
  ['ux', 'research', 'qa', 'web', 'video', 'biz'],
  ['sales', 'pr', 'admin', 'buying', 'accounting', 'production'],
];
const cast = ['traveler', 'golden', 'border', 'poodle', 'shiba', 'corgi', 'shepherd', 'mayor'];

function element(tag, label = '', className = '') {
  const node = document.createElement(tag);
  node.textContent = label;
  node.className = className;
  return node;
}

function button(parent, label, action, className = '') {
  const node = element('button', label, className);
  node.type = 'button';
  node.addEventListener('click', action);
  parent.append(node);
  return node;
}

function actor(kind, skin = '') {
  const sprite = element('div', '', 'sprite ' + kind);
  const index = cast.indexOf(skin || kind);
  sprite.setAttribute('aria-hidden', 'true');
  sprite.style.backgroundPosition = (index % 4) * (100 / 3) + '% ' + Math.floor(index / 4) * 100 + '%';
  return sprite;
}

function world(kind, sprite, route) {
  const stage = element('div', '', 'world ' + kind);
  const landscape = element('div', '', 'landscape');
  landscape.setAttribute('aria-hidden', 'true');
  if (route) {
    const atlas = workplaceAtlases.findIndex(ids => ids.includes(route.id));
    const index = workplaceAtlases[atlas].indexOf(route.id);
    const tile = element('div', '', 'workplace-art');
    tile.style.backgroundImage = 'url("assets/workplaces' + ['', '-b', '-c'][atlas] + '.jpg")';
    tile.style.backgroundPosition = (index % 3) * 50 + '% ' + Math.floor(index / 3) * 100 + '%';
    landscape.append(tile);
  }
  stage.append(landscape, actor('traveler'), actor('dog', sprite));
  return stage;
}

function render({ kind, title, narrator, line, sprite = 'mayor', route, focus = true }) {
  clearTimeout(feedingTimer);
  clearTimeout(movementTimer);
  cancelAnimationFrame(movementFrame);
  const stage = world(kind, sprite, route);
  const hud = element('div', 'Pawtopia', 'hud');
  const talk = element('div', '', 'dialogue');
  const heading = element('h1', title);
  heading.id = 'scene-title';
  heading.tabIndex = -1;
  const caption = element('p', line);
  const actions = element('div', '', 'actions');
  talk.append(element('div', narrator, 'speaker'), heading, caption, actions);
  scene.replaceChildren(stage, hud, talk);
  if (focus) heading.focus({ preventScroll: true });
  return { stage, actions };
}

function welcome(focus = true) {
  const { actions } = render({
    kind: 'gate', title: '汪汪職涯小鎮', narrator: '柯基村長',
    line: '歡迎，小旅人！選一個你曾在自己身上看見的強項，再跟狗狗一起出發。', focus,
  });
  button(actions, '進入小鎮', () => { townMusic.start(); showStrength(); });
}

function changeStrength(delta) {
  strengthIndex = (strengthIndex + delta + strengths.length) % strengths.length;
  showStrength();
}

function showStrength() {
  const current = strengths[strengthIndex];
  const { stage, actions } = render({
    kind: 'square', title: current.name,
    narrator: current.group + ' · ' + (strengthIndex + 1) + '／' + strengths.length,
    line: current.description + ' ' + current.example,
    sprite: companionPlans[current.id]?.[2] ?? 'corgi',
  });
  stage.dataset.pose = String(strengthIndex % 3);
  button(actions, favorites.has(current.id) ? '移出收藏' : '這有點像我・收藏', () => {
    if (favorites.has(current.id)) favorites.delete(current.id);
    else if (favorites.size < 3) favorites.add(current.id);
    else {
      scene.querySelector('.dialogue p').textContent = '已收藏三個強項。可以先到收藏袋移除一個，再加入這個。';
      return;
    }
    try { localStorage.setItem('pawtopia.favorites', JSON.stringify([...favorites])); } catch {}
    showStrength();
  });
  button(actions, '收藏袋（' + favorites.size + '／3）', showFavorites, 'secondary');
  const previous = button(stage, '‹', () => changeStrength(-1), 'arrow previous');
  previous.setAttribute('aria-label', '上一個強項');
  const next = button(stage, '›', () => changeStrength(1), 'arrow next');
  next.setAttribute('aria-label', '下一個強項');
}

function showFavorites() {
  const { actions } = render({
    kind: 'square', title: '我的強項收藏', narrator: '柯基村長',
    line: favorites.size ? '挑一個你想探索的強項出發。收藏可以隨時增減。' : '先用左右箭頭認識強項，收藏一到三個讓你有共鳴的強項。',
  });
  for (const id of favorites) {
    const item = strengths.find(entry => entry.id === id);
    const row = element('div', '', 'favorite-row');
    button(row, item.name + '・出發', () => meet(item));
    button(row, '移除' + item.name, () => {
      favorites.delete(id);
      try { localStorage.setItem('pawtopia.favorites', JSON.stringify([...favorites])); } catch {}
      showFavorites();
    }, 'secondary');
    actions.append(row);
  }
  button(actions, '繼續認識強項', showStrength, 'secondary');
}

function exploreTraining() {
  const { stage, actions } = render({
    kind: 'work exploring', title: '新人訓練的一天', narrator: '暖暖',
    line: '點前景走道就能左右走動。電腦、資料夾和電話會微微發亮，點物件，我們就走過去看看。',
    sprite: companion.sprite, route: career,
  });
  stage.classList.add('office-side');
  const player = stage.querySelector('.traveler');
  const dog = stage.querySelector('.dog');
  const status = element('div', '', 'exploration-status');
  stage.append(status);
  let activeStop = null;
  let page = 0;

  let playerX = 43;
  let dogX = 34;
  let destination = playerX;
  let arrival = null;
  let travelDirection = 1;
  let lastTime = 0;
  let startedAt = 0;
  function move(x, arrived) {
    destination = Math.max(12, Math.min(88, x));
    travelDirection = Math.sign(destination - playerX) || travelDirection;
    arrival = arrived;
    startedAt = performance.now();
    lastTime = startedAt;
    cancelAnimationFrame(movementFrame);
    movementFrame = requestAnimationFrame(walk);
  }
  function walk(now) {
    const dt = Math.min((now - lastTime) / 1000, .05);
    lastTime = now;
    const direction = Math.sign(destination - playerX);
    const distance = Math.abs(destination - playerX);
    const moving = distance > .15;
    playerX += direction * Math.min(distance, dt * 20);
    const dogTarget = Math.max(6, Math.min(94, destination - travelDirection * 9));
    const dogDistance = Math.abs(dogTarget - dogX);
    const dogMoving = now - startedAt > 220 && dogDistance > .2;
    if (dogMoving) dogX += Math.sign(dogTarget - dogX) * Math.min(dogDistance, dt * 21);
    for (const [node, xPos, walking, facing] of [[player, playerX, moving, direction], [dog, dogX, dogMoving, Math.sign(dogTarget - dogX)]]) {
      node.style.left = xPos + '%';
      node.classList.toggle('stepping', walking);
      if (walking) node.style.setProperty('--facing', facing < 0 ? '-1' : '1');
      if (walking) node.style.setProperty('--frame', (Math.floor(now / 140) % 4) * (100 / 3) + '%');
    }
    for (const marker of stage.querySelectorAll('.explore-marker')) {
      marker.classList.toggle('nearby', Math.abs(Number(marker.style.left.replace('%','')) - playerX) < 10);
    }
    if (moving || dogDistance > .2) movementFrame = requestAnimationFrame(walk);
    else if (arrival) { const callback = arrival; arrival = null; callback(); }
  }

  function updateProgress() {
    status.textContent = '已探索 ' + explored.size + '／3';
    for (const marker of stage.querySelectorAll('.explore-marker')) {
      const stop = trainingStops[Number(marker.dataset.index)];
      marker.classList.toggle('visited', explored.has(stop.name));
    }
  }

  function idle() {
    arrival = null;
    activeStop = null;
    scene.querySelector('h1').textContent = '繼續自由探索';
    scene.querySelector('.dialogue p').textContent = explored.size === 3
      ? '三個工作環節都看過了！隨時可以再看看，或和暖暖聊聊今天的發現。'
      : '可以點另一個工作物件，也可以點地面走動。';
    actions.replaceChildren();
    if (explored.size === 3) button(actions, '和暖暖回顧強項', trainingReview);
    button(actions, '返回職涯岔路', crossroads, 'secondary');
  }

  function showPage() {
    scene.querySelector('h1').textContent = activeStop.name + '・' + activeStop.type;
    scene.querySelector('.dialogue p').textContent = activeStop.lines[page];
    actions.replaceChildren();
    if (page + 1 < activeStop.lines.length) {
      button(actions, '看看接下來的工作', () => { page++; showPage(); });
    } else {
      button(actions, '看工作成果', () => {
        explored.add(activeStop.name);
        updateProgress();
        scene.querySelector('.dialogue p').textContent = activeStop.result;
        actions.replaceChildren();
        button(actions, '回到自由探索', idle);
      });
    }
    button(actions, '先看看別處', idle, 'secondary');
  }

  stage.addEventListener('click', event => {
    if (event.target.closest('button')) return;
    const rect = stage.getBoundingClientRect();
    if ((event.clientY - rect.top) / rect.height < .56) return;
    arrival = null;
    move((event.clientX - rect.left) / rect.width * 100);
  });
  for (const [index, stop] of trainingStops.entries()) {
    const marker = button(stage, '', () => {
      activeStop = stop; page = 0;
      actions.replaceChildren();
      button(actions, '返回職涯岔路', crossroads, 'secondary');
      scene.querySelector('.dialogue p').textContent = '走到' + stop.name + '旁邊…';
      move(stop.x, showPage);
    }, 'explore-marker');
    marker.setAttribute('aria-label', stop.name);
    marker.append(element('span', stop.name, 'object-label'));
    marker.dataset.index = String(index);
    marker.style.left = stop.x + '%';
    marker.style.top = stop.y + '%';
  }
  updateProgress();
  button(actions, '返回職涯岔路', crossroads, 'secondary');
}

function trainingReview() {
  const { actions } = render({
    kind: 'work', title: '今天，仁慈用在哪裡？', narrator: '暖暖',
    line: '我們安排課程、整理學習紀錄，也遇到「上完課卻不會用」的困難。我先了解同仁需要什麼幫助，再協調講師與帶教同仁提供支持。這是仁慈在工作裡的一種做法，也需要組織、溝通與分析。',
    sprite: companion.sprite, route: career,
  });
  button(actions, '送暖暖罐罐', reward);
  button(actions, '再逛逛工作場所', exploreTraining, 'secondary');
}

function meet(current) {
  strength = current;
  if (!companionPlans[current.id]) {
    const { actions } = render({
      kind: 'square', title: '你選了「' + current.name + '」', narrator: '柯基村長',
      line: '這個強項的代表狗狗還在準備中。你可以先聽其他故事，再選一位夥伴出發。',
    });
    button(actions, '回到強項故事', showStrength);
    return;
  }
  companion = careersFor(current.id);
  const { actions } = render({
    kind: 'square', title: '遇見' + companion.name, narrator: companion.name,
    line: '我是' + companion.breed + '，你選的強項是「' + current.name + '」。前面有三個工作地點，我們一起去看看吧！',
    sprite: companion.sprite,
  });
  button(actions, '走到職涯岔路', crossroads);
  button(actions, '重選強項', showStrength, 'secondary');
}

function crossroads() {
  const { stage, actions } = render({
    kind: 'crossroads', title: '職涯岔路', narrator: companion.name,
    line: '點一棟建築，進去看看這份工作的一天。', sprite: companion.sprite,
  });
  const paths = element('div', '', 'paths');
  paths.setAttribute('role', 'group');
  paths.setAttribute('aria-label', '三條職涯路線');
  for (const route of companion.careers) {
    const destination = button(paths, '', () => {
      career = route;
      if (route.id === 'training') { explored.clear(); exploreTraining(); }
      else workplace(0, 0);
    }, 'destination');
    const complete = isComplete(route);
    destination.append(element('span', '', 'house'), element('strong', route.title),
      element('span', complete ? '已點亮' : route.place, 'place'));
  }
  stage.append(paths);
  button(actions, '回到夥伴身邊', () => meet(strength), 'secondary');
}

function storageKey(route) {
  return 'pawtopia.route.' + route.id + '.completed';
}

function isComplete(route) {
  try {
    return localStorage.getItem(storageKey(route)) === 'true'
      || (route.id === 'training' && localStorage.getItem('pawtopia.kindness-training.completed') === 'true');
  } catch {
    return false;
  }
}

function workplace(sceneIndex, frameIndex) {
  const chapter = career.scenes[sceneIndex];
  const [beat, line] = chapter.frames[frameIndex];
  const { stage, actions } = render({
    kind: 'work', title: chapter.title, narrator: career.place + ' · ' + (sceneIndex + 1) + '／' + career.scenes.length,
    line: beat === chapter.title ? line : beat + '｜' + line, sprite: companion.sprite, route: career,
  });
  stage.dataset.pose = String((sceneIndex + frameIndex) % 3);
  if (frameIndex + 1 < chapter.frames.length) {
    button(actions, '繼續播放', () => workplace(sceneIndex, frameIndex + 1));
  } else if (sceneIndex + 1 < career.scenes.length) {
    button(actions, '下一個工作場景', () => workplace(sceneIndex + 1, 0));
  } else {
    button(actions, '完成體驗', reward);
  }
  button(actions, '返回岔路', crossroads, 'secondary');
}

function reward() {
  const { stage, actions } = render({
    kind: 'celebrate', title: '完成職涯體驗！', narrator: '柯基村長',
    line: '你和' + companion.name + '一起體驗了「' + career.title + '」的工作。送牠一個罐罐吧！',
    sprite: companion.sprite,
  });
  const can = element('div', '', 'food-can');
  can.setAttribute('aria-label', '狗狗的罐頭');
  can.append(element('i', '', 'can-lid'), element('i', '', 'can-food'), element('span', '肉肉', 'can-label'));
  stage.append(can);
  const eatIndex = ['golden', 'border', 'poodle', 'shiba', 'corgi', 'shepherd'].indexOf(companion.sprite);
  const eating = element('div', '', 'eating-dog');
  eating.style.backgroundPosition = (eatIndex % 3) * 50 + '% ' + Math.floor(eatIndex / 3) * 100 + '%';
  eating.setAttribute('aria-hidden', 'true');
  stage.append(eating);
  const caption = scene.querySelector('.dialogue p');
  const feed = button(actions, '餵' + companion.name + '罐罐', () => {
    feed.disabled = true;
    feed.textContent = '開罐中…';
    stage.classList.add('feeding');
    caption.textContent = '啵！罐罐打開了，' + companion.name + '聞到香味，靠了過來。';
    feedingTimer = setTimeout(() => {
      stage.classList.add('eating');
      feed.textContent = '正在吃罐罐…';
      caption.textContent = companion.name + '低下頭，一口一口吃著罐罐。';
      feedingTimer = setTimeout(() => {
        stage.classList.remove('eating');
        stage.classList.add('satisfied');
        caption.textContent = companion.name + '吃飽了，開心地抬起頭！這條職涯路也亮起了。';
        try {
          localStorage.setItem(storageKey(career), 'true');
        } catch {
          // The story can finish even when storage is unavailable.
        }
        actions.replaceChildren();
        button(actions, '看看探索成果', ending);
      }, 3600);
    }, 1500);
  });
}

function ending() {
  const { actions } = render({
    kind: 'celebrate', title: '這條職涯路亮起了', narrator: companion.name,
    line: '我們今天從「' + strength.name + '」出發。你也可以回岔路看看同一個強項怎麼在別的工作派上用場。',
    sprite: companion.sprite,
  });
  button(actions, '走另一條職涯路', crossroads);
  button(actions, '回到強項收藏', showFavorites, 'secondary');
  button(actions, '回小鎮入口', () => welcome(), 'secondary');
}

document.addEventListener('keydown', event => {
  if (event.altKey || event.ctrlKey || event.metaKey || !scene.querySelector('.world.square .arrow')) return;
  if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
  event.preventDefault();
  changeStrength(event.key === 'ArrowLeft' ? -1 : 1);
});

welcome(false);
