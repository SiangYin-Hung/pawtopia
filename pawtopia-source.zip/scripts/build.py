"""Build a self-contained HTML for offline use and GitHub Pages."""
from pathlib import Path
import base64, mimetypes, re, shutil, zipfile
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'publish'
OUT.mkdir(exist_ok=True)
def asset(path):
    p = ROOT / path
    return 'data:' + mimetypes.guess_type(p)[0] + ';base64,' + base64.b64encode(p.read_bytes()).decode()
html = (ROOT / 'index.html').read_text()
css = (ROOT / 'css/style.css').read_text()
css = re.sub(r'\.\./assets/[^"\)]+', lambda m: asset(m[0][3:]), css)
html = html.replace('<link rel="stylesheet" href="css/style.css">', '<style>' + css + '</style>')
scripts = []
for path in ['data/strengths.js', 'data/routes.js', 'js/music.js', 'js/main.js']:
    code = (ROOT / path).read_text()
    if path == 'js/main.js':
        old = "'url(\"assets/workplaces' + ['', '-b', '-c'][atlas] + '.jpg\")'"
        urls = ["'url(\"" + asset('assets/workplaces' + suffix + '.jpg') + "\")'" for suffix in ['', '-b', '-c']]
        assert old in code
        code = code.replace(old, '[' + ','.join(urls) + '][atlas]')
    html = html.replace('<script defer src="' + path + '"></script>', '')
    scripts.append(code)
html = html.replace('</body>', '<script>\n' + '\n'.join(scripts).replace('</script', '<\\/script') + '\n</script>\n</body>')
(OUT / 'index.html').write_text(html)
shutil.copyfile(ROOT / 'README.md', OUT / 'README.md')
with zipfile.ZipFile(OUT / 'pawtopia-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in ['index.html', 'README.md', 'scripts/build.py', 'css/style.css', 'data/strengths.js', 'data/routes.js', 'js/main.js', 'js/music.js']:
        archive.write(ROOT / path, path)
    for p in (ROOT / 'assets').iterdir():
        if p.is_file() and p.name not in ['.DS_Store', 'cast.png', 'eating.png']:
            archive.write(p, p.relative_to(ROOT))
print('Standalone HTML:', (OUT / 'index.html').stat().st_size, 'bytes')
